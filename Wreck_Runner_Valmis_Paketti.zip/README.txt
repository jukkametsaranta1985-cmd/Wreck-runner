WRECK RUNNER – VALMIS PELIPAKETTI

index.html on täysin itsenäinen selainpeli.
Puhelin: keskeltä hyppy, vasen/oikea alareuna liike.
Tietokone: välilyönti/nuoli ylös hyppy, vasen/oikea liike.

Päähenkilö on tyylitelty lähettämäsi kuvan perusteella:
pinkki lippis, parta, tatuointihenkiset käsivarret, musta toppi,
farkut ja maiharit.

Julkaisu: lataa index.html GitHubiin ja ota GitHub Pages käyttöön.
